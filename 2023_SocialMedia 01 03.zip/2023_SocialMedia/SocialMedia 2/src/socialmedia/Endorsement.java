package socialmedia;

/**
 * Endorsement class is a simple supporting class that contains methods that will be called by the SocialMedia class,
 * and is the child class of Post.
 * @author Elijah Williams, Rashed Zou'bi
 * @version 1.0
 */

public class Endorsement extends Post{
    int originalPostId;

    public Endorsement(int userId, int originalPostId, String message){
        this.userId = userId;
        this.originalPostId = originalPostId;
        this.postId = Post.nextId;
        this.message = message;
        Post.nextId++;
    }
}