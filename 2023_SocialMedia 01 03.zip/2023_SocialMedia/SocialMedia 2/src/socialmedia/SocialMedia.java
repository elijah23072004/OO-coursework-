package socialmedia;

public class SocialMedia {
    
}