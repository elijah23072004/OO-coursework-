package socialmedia;

/**
 * User class is a simple supporting class that contains methods that will be called by the SocialMedia class.
 * @author Elijah Williams, Rashed Zou'bi
 * @version 1.0
 */

public class User{
    String handle;
    String description;
    int id;
    static int nextId=0;
    public User(String handle, String description) {
        this.description=description;
        this.id=User.nextId;
        User.nextId++;
        this.handle=handle;
    }
    public User(String handle) {
        this.id=User.nextId;
        User.nextId++;
        this.handle=handle;
    }
    public void changeHandle(String handle) {
        this.handle=handle;
    }
    public void changeDescription(String description) {
        this.description=description;
    }
}