package socialmedia;
import java.util.ArrayList;

/**
 * Data class will store all the users and posts created in the SocialMedia class using four static attributes.
 * @author Elijah Williams, Rashed Zou'bi
 * @version 1.0
 */

public class Data {
    static ArrayList<User> users = new ArrrayList<>();
    static ArrayList<Post> posts = new ArrayList<>();
    static ArrayList<Comment> comments = new ArrayList();
    static ArrayList<Endorsement> endorsements = new ArrayList<>();
}