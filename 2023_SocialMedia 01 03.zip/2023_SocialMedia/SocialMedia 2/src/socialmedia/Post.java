package socialmedia;

/**
 * Post class is a simple supporting class that contains methods that will be called by the SocialMedia class, and is
 * the parent class of Comment and Endorsement.
 * @author Elijah Williams, Rashed Zou'bi
 * @version 1.0
 */

public class Post{
    int userId;
    int postId;
    static int nextId = 0;
    String message;
    int commentCount = 0;
    int endorsementCount = 0;

    public Post(int userId, String message) throws InvalidPostException {
        this.userId=userId;
        this.postId = Post.nextId;
        Post.nextId++;
        if (message.length()<=0 || message.length()>100){
            throw InvalidPostException;
        }
        this.message=message;
    }
    public void CommentCreated() {
        commentCount++;
    }
    public void EndorsementCreated() {
        endorsementCount++;
    }
    public void CommentDeleted() {
        commentCount--;
    }
    public void EndorsementDeleted() {
        endorsementCount--;
    }
}