package socialmedia;

/**
 * Comment class is a simple supporting class that contains methods that will be called by the SocialMedia class, and is
 * the child class of Post.
 * @author Elijah Williams, Rashed Zou'bi
 * @version 1.0
 */

public class Comment extends Post{
    int originalPostId;

    public Comment(int userId, String message, int originalPostId) {
        super()
        this.originalPostId = originalPostId;
    }

    public void originalDeleted() {
        originalPostId = -1;
    }
}